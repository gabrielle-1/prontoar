package com.gabrielle.prontoar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProntoarApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProntoarApplication.class, args);
	}

}
