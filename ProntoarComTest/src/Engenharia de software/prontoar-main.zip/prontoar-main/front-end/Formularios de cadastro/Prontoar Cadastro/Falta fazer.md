Falta pegar informações da Tela de Login, no JavaScript.
